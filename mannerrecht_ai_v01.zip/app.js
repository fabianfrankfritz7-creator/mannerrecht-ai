const messages=document.querySelector("#messages");
const form=document.querySelector("#chatForm");
const input=document.querySelector("#question");

const official="https://www.gesetze-im-internet.de/aktuell.html";

function addMessage(text, who="assistant"){
  const div=document.createElement("div");
  div.className="msg "+who;
  div.innerHTML=text;
  messages.appendChild(div);
  messages.scrollTop=messages.scrollHeight;
}

function answer(q){
  const s=q.toLowerCase();
  let topic="general", law="", guidance="";
  if(/kind|kindern|sohn|tochter|vater|mutter|umgang|sorgerecht|jugendamt/.test(s)){
    topic="family";
    law="Family law / FamFG and BGB provisions on parental responsibility and contact.";
    guidance="The exact answer depends on parental responsibility, an existing court order or agreement, the child's circumstances, and what has actually happened. Preserve messages, dates and existing orders. If contact is being blocked, the appropriate family-court procedure should be checked promptly.";
  } else if(/polizei|beschuldigt|straf|vorladung|ermittlung|anzeige/.test(s)){
    topic="criminal";
    law="Criminal procedure / StPO may be relevant, depending on whether you are a suspect, witness or another participant.";
    guidance="Do not assume that a police letter has the same legal effect as a court order. First identify your procedural status and any deadline. A lawyer can advise on whether and how to respond.";
  } else if(/arbeit|arbeitgeber|kündigung|gekündigt|job/.test(s)){
    topic="employment";
    law="Employment law, including the Kündigungsschutzgesetz where applicable.";
    guidance="Dismissal matters can involve short deadlines. Keep the original letter, note the date it was received, and have the deadline checked immediately by a lawyer or qualified legal adviser.";
  } else if(/wohnung|vermieter|miete|mietvertrag|rauswurf/.test(s)){
    topic="housing";
    law="German tenancy law under the BGB may apply.";
    guidance="Keep the lease, notices, payment records and communications. The legal effect depends heavily on the wording of the notice and the dates.";
  } else {
    law="The applicable law cannot be determined reliably from a short description alone.";
    guidance="Give the date, country/state, people involved, what happened in chronological order, and any document or deadline you have. Do not post sensitive personal data.";
  }

  return `<strong>Preliminary legal-information assessment</strong>
  <p><b>Area:</b> ${topic}</p>
  <p><b>Relevant framework:</b> ${law}</p>
  <p><b>What this means:</b> ${guidance}</p>
  <p><b>Next step:</b> I would retrieve the current statutory text and relevant decisions before giving a case-specific answer. This prototype does not yet perform that live retrieval.</p>
  <p><b>Official source:</b> <a href="${official}" target="_blank" rel="noopener">Gesetze im Internet ↗</a></p>
  <p style="color:#9eabc4;font-size:12px">This is general legal information, not legal representation or a prediction of a court outcome.</p>`;
}

form.addEventListener("submit",e=>{
  e.preventDefault();
  const q=input.value.trim(); if(!q)return;
  addMessage(q,"user"); input.value="";
  setTimeout(()=>addMessage(answer(q),"assistant"),250);
});

document.querySelectorAll("[data-question]").forEach(b=>b.addEventListener("click",()=>{
  input.value=b.dataset.question; input.focus();
}));
document.querySelectorAll("[data-topic]").forEach(b=>b.addEventListener("click",()=>{
  input.value={family:"I need help with a family-law issue.",criminal:"I need help with a criminal-law issue.",employment:"I need help with an employment-law issue.",housing:"I need help with a housing-law issue.",police:"I need help with a police/investigation issue.",general:"I have another legal question."}[b.dataset.topic];
  input.focus();
}));
