# MännerRecht AI — v0.1

This is a free, static prototype of a German legal-information assistant.

## Run it
No installation is required. Open `index.html` in a browser.

For free hosting, upload the folder to a static host such as GitHub Pages or Cloudflare Pages.

## What this version does
- Responsive legal-assistant interface
- Topic selection
- Multilingual UI selector (interface scaffold)
- Basic question routing
- Official German legal-source links
- Legal-information disclaimer

## What it deliberately does NOT do yet
- It does not claim to be a lawyer.
- It does not provide legal representation.
- It does not yet perform live retrieval of the complete German legal corpus.
- It does not yet connect to a paid or local AI model.
- It does not yet guarantee that an answer reflects the law on a particular date.

## Next build
1. Import authoritative legal texts from official sources.
2. Create a searchable legal database.
3. Add retrieval-augmented generation (RAG).
4. Force every substantive answer to show source + date.
5. Add document/PDF analysis.
6. Add German-state-specific law and procedure where applicable.
7. Add real language translation.
8. Add privacy/security controls.
9. Add lawyer escalation and emergency/deadline detection.

Official starting point:
https://www.gesetze-im-internet.de/aktuell.html
Latest-update service:
https://www.gesetze-im-internet.de/aktuDienst.html
